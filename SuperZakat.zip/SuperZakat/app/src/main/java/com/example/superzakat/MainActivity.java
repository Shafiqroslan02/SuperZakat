package com.example.superzakat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText goldWeight;
    Spinner goldType,goldRate;
    Button btnCalc;
    TextView goldValue,payable,total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        goldWeight = findViewById(R.id.goldWeight);
        goldType = findViewById(R.id.goldType);
        goldRate = findViewById(R.id.goldPerGram);
        btnCalc = findViewById(R.id.btnCalc);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        String[] items1 = {"Keep", "Wear"};
        String[] items2 = {"280", "250"};

        goldValue = findViewById(R.id.goldValue);
        payable = findViewById(R.id.payable);
        total = findViewById(R.id.total);

        btnCalc.setOnClickListener((View.OnClickListener) this);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items1);
        goldType.setAdapter(adapter1);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items2);
        goldRate.setAdapter(adapter2);
        goldType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, "Selected: " + items1[position], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        goldRate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, "Selected: " + items2[position], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_home) {
            startActivity(new Intent(this, MainActivity.class));
            return true;
        } else if (item.getItemId() == R.id.action_elearning) {
            startActivity(new Intent(this, elearning.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnCalc){
            double weight = Double.parseDouble(goldWeight.getText().toString());
            double rate = Double.parseDouble(goldRate.getSelectedItem().toString());
            String type = goldType.getSelectedItem().toString();
            double gold,valueGold = 0,pay = 0,zakat = 0;
            if (type == "Keep"){
                if (rate == 280){
                    gold = weight - 85;
                    if(gold < 0){
                        valueGold = 0;
                    } else {
                        valueGold = gold;
                    }
                    pay = valueGold * 280;
                    zakat = pay * 0.025;
                } else if (rate == 250) {
                    gold = weight - 85;
                    if(gold <= 0){
                        valueGold = 0;
                    } else {
                        valueGold = gold;
                    }
                    if(valueGold <= 0){
                        valueGold = 0;
                    }
                    pay = valueGold * 250;
                    zakat = pay * 0.025;
                }
            } else if (type == "Wear") {
                if (rate == 280){
                    gold = weight - 200;
                    if(gold <= 0){
                        valueGold = 0;
                    } else {
                        valueGold = gold;
                    }
                    pay = valueGold * 280;
                    zakat = pay * 0.025;
                } else if (rate == 250) {
                    gold = weight - 200;
                    if(gold <= 0){
                        valueGold = 0;
                    } else {
                        valueGold = gold;
                    }
                    pay = valueGold * 250;
                    zakat = pay * 0.025;
                }
            }
            goldValue.setText("Gold Value: "+valueGold+"g");
            payable.setText("Zakat Payable: RM"+pay);
            total.setText("Total Zakat: RM"+zakat);
        }
    }
}